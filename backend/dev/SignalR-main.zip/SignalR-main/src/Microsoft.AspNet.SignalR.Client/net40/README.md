# .NET Framework 4.0 Compatibility

This directory contains files that are needed only in .NET Framework 4.0 builds to provide compatibility.
