Issues related to the Asp.NET Core version of SignalR should be filed in the AspNetCore repo: https://github.com/aspnet/AspNetCore/issues/new/choose
Please remove this line and the line above before submitting a new issue.

### Expected  behavior

### Actual behavior

### Steps to reproduce

